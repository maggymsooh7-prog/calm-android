# Calm Android app

This project packages your supplied `Calm.html` in an Android WebView.

## Build an APK with Android Studio
1. Open this folder in Android Studio on a computer.
2. Let Gradle sync and install Android SDK 35 if prompted.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the generated debug APK.

## Build an APK in GitHub Actions
This project includes `.github/workflows/android.yml`.
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Select **Build Calm APK**, then **Run workflow** (or push to `main`).
4. When the workflow finishes, open the run and download the `Calm-debug-apk` artifact.
5. Extract the artifact and install `app-debug.apk` on your Android phone. Android may ask you to allow installs from the app you used to open it.

The workflow builds a debug APK; it is suitable for personal testing, not Play Store publishing.

## App details
- Focus timer: 15, 25, and 50 minutes
- Five-minute break timer
- Habit tracker and streaks
- Saves progress using WebView DOM storage

The Google Fonts stylesheet in the HTML needs internet access; system font fallbacks remain available offline.
